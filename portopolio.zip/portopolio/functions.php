<?php 
    $koneksi = mysqli_connect("localhost", "root", "", "portofolio");
    $hasil = mysqli_query ($koneksi, "SELECT * FROM user")

?>